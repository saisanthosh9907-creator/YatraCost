package com.example.tripcost;

import java.math.BigDecimal;

public class TripCostRequest {

    private double distanceKm;
    private double mileageKmPerLitre;
    private BigDecimal fuelPricePerLitre;
    private int tripDays;
    private BigDecimal foodCostPerDay;
    private BigDecimal stayCostPerDay;
    private String weatherCondition;

    public double getDistanceKm() { return distanceKm; }
    public void setDistanceKm(double distanceKm) { this.distanceKm = distanceKm; }

    public double getMileageKmPerLitre() { return mileageKmPerLitre; }
    public void setMileageKmPerLitre(double mileageKmPerLitre) { this.mileageKmPerLitre = mileageKmPerLitre; }

    public BigDecimal getFuelPricePerLitre() { return fuelPricePerLitre; }
    public void setFuelPricePerLitre(BigDecimal fuelPricePerLitre) { this.fuelPricePerLitre = fuelPricePerLitre; }

    public int getTripDays() { return tripDays; }
    public void setTripDays(int tripDays) { this.tripDays = tripDays; }

    public BigDecimal getFoodCostPerDay() { return foodCostPerDay; }
    public void setFoodCostPerDay(BigDecimal foodCostPerDay) { this.foodCostPerDay = foodCostPerDay; }

    public BigDecimal getStayCostPerDay() { return stayCostPerDay; }
    public void setStayCostPerDay(BigDecimal stayCostPerDay) { this.stayCostPerDay = stayCostPerDay; }

    public String getWeatherCondition() { return weatherCondition; }
    public void setWeatherCondition(String weatherCondition) { this.weatherCondition = weatherCondition; }
}
