package com.example.tripcost;

import java.math.BigDecimal;

public class TripCostResponse {

    private BigDecimal fuelRequiredLitres;
    private BigDecimal fuelCost;
    private BigDecimal foodCost;
    private BigDecimal stayCost;
    private BigDecimal totalTripCost;

    public TripCostResponse(BigDecimal fuelRequiredLitres, BigDecimal fuelCost,
                            BigDecimal foodCost, BigDecimal stayCost,
                            BigDecimal totalTripCost) {
        this.fuelRequiredLitres = fuelRequiredLitres;
        this.fuelCost = fuelCost;
        this.foodCost = foodCost;
        this.stayCost = stayCost;
        this.totalTripCost = totalTripCost;
    }

    public BigDecimal getFuelRequiredLitres() { return fuelRequiredLitres; }
    public BigDecimal getFuelCost() { return fuelCost; }
    public BigDecimal getFoodCost() { return foodCost; }
    public BigDecimal getStayCost() { return stayCost; }
    public BigDecimal getTotalTripCost() { return totalTripCost; }
}
