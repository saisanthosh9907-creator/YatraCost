package com.example.tripcost;

import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.math.RoundingMode;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class TripCostController {

    @PostMapping("/trip-cost")
    public TripCostResponse calculateTripCost(@RequestBody TripCostRequest req) {

        BigDecimal fuelMultiplier  = BigDecimal.ONE;
        BigDecimal foodMultiplier  = BigDecimal.ONE;
        BigDecimal stayMultiplier  = BigDecimal.ONE;

        String wc = (req.getWeatherCondition() == null) ? "NORMAL"
                : req.getWeatherCondition().toUpperCase();

        switch (wc) {
            case "RAINY" -> {
                fuelMultiplier = new BigDecimal("1.05");
                foodMultiplier = new BigDecimal("1.10");
                stayMultiplier = new BigDecimal("1.05");
            }
            case "EXTREME" -> {
                fuelMultiplier = new BigDecimal("1.10");
                foodMultiplier = new BigDecimal("1.20");
                stayMultiplier = new BigDecimal("1.15");
            }
            default -> { }
        }

        BigDecimal distanceKm = BigDecimal.valueOf(req.getDistanceKm());
        BigDecimal mileage = BigDecimal.valueOf(req.getMileageKmPerLitre());

        BigDecimal fuelRequired = distanceKm
                .divide(mileage, 2, RoundingMode.HALF_UP);

        BigDecimal baseFuelCost = fuelRequired.multiply(req.getFuelPricePerLitre());
        BigDecimal totalFuelCost = baseFuelCost.multiply(fuelMultiplier);

        BigDecimal baseFood = req.getFoodCostPerDay()
                .multiply(BigDecimal.valueOf(req.getTripDays()));
        BigDecimal totalFoodCost = baseFood.multiply(foodMultiplier);

        BigDecimal baseStay = req.getStayCostPerDay()
                .multiply(BigDecimal.valueOf(req.getTripDays()));
        BigDecimal totalStayCost = baseStay.multiply(stayMultiplier);

        BigDecimal totalTripCost = totalFuelCost
                .add(totalFoodCost)
                .add(totalStayCost)
                .setScale(2, RoundingMode.HALF_UP);

        return new TripCostResponse(
                fuelRequired.setScale(2, RoundingMode.HALF_UP),
                totalFuelCost.setScale(2, RoundingMode.HALF_UP),
                totalFoodCost.setScale(2, RoundingMode.HALF_UP),
                totalStayCost.setScale(2, RoundingMode.HALF_UP),
                totalTripCost
        );
    }
}
