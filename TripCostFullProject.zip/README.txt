Trip Cost Estimator – Full Project (Frontend + Java Spring Boot Backend)

Structure:
- frontend/YatraCostPro.html  → Open in browser (just double-click)
- backend/                    → Spring Boot project

How to run backend:
1. Open a terminal in the 'backend' folder.
2. Run: mvn spring-boot:run
3. Backend will start at: http://localhost:8080

API:
POST http://localhost:8080/api/trip-cost
JSON body:
{
  "distanceKm": 570,
  "mileageKmPerLitre": 18,
  "fuelPricePerLitre": 110,
  "tripDays": 2,
  "foodCostPerDay": 500,
  "stayCostPerDay": 1500,
  "weatherCondition": "RAINY"
}
